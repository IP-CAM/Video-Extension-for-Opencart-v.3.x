Version 1.0 - extension by Anas
Adds the ability to upload videos to a video directoru in the image folder and then we can play thoes videos from the site after placing the extension in the required layout.

If you want to contribute just send your modifications.
Your name/copyright will be added.

The script is free for personal/business use but not for any other purpose (modifications, sale, etc).